/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gamebasicmoi;

/**
 *
 * @author moises
 */
public class Sprite {
    //coordenadas x,y del objeto tamaño 
    public int x, y, tam;
    public double dx, dy;
      // obtener coordenadas  x
    public int getx() {
        return x;
    }

    public int getY() {
        return y;
    }

    public double getDX() {
        return dx;

    }

    public double getDY() {
        return dy;
    }

    public int getTam() {
        return tam;
    }
}
