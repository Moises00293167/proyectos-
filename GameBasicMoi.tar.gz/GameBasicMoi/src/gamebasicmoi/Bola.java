/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gamebasicmoi;

/**
 *
 * @author moises
 */
public class Bola extends Sprite {

    // Metodo construcctor de la clase Bola 
    public Bola() {
        // x = (int) (Math.random()*100*50);
        x = 100;
        y = 30;
        dx = 5;
        dy = 0;
        tam = 50;
    }

    public void Mover() {
        //definir una variable que almacenara la diferencia 
        int dis;
        x += dx;
        y += dy;
        dy += 0.8;
        // definimos el valor de diferencia 
        dis = y + tam - 600;
        if(dis > 0 && dy > 0 ){
            y = 500 - tam;
            dy=-10;
        }

    }
}
