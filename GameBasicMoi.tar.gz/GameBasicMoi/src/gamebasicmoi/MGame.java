/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gamebasicmoi;

import java.util.Hashtable;

/**
 *
 * @author moises
 */
public class MGame {

    // Definir codigo de presion de teclas 
    private int TEC_ESPACIO = 32;
    private int TEC_IZQ = 37;
    private int TEC_DER = 39;
    private int TEC_ARRIBA = 38;
    private int TEC_ABAJO = 40;
    private int TEC_ENTER = 10;
    private int TEC_ESC = 27;
    // definir variables de interaccion 
    private int nEstado = 0; // 0portada , 1.-jugando 2 Game over 
    private int nFase = 0; // 0 - n
    // definir una tabla  que almacena los datos 
    private Hashtable htTeclas = new Hashtable();
    // crear instancia de la clace  bola 
    Bola bola;
// almacena los codigo de las teclas pulsadas en el hashtable

    public void pulsaTecla(int codigo) {
        try {
            htTeclas.put(codigo, 1);
            System.out.println("codigo" + codigo);
        } catch (Exception e) {
        }

    }
// rwemover los codigos de las teclas almacenadas 

    public void sueltaTecla(int codigo) {
        try {
            htTeclas.remove(codigo);

        } catch (Exception e) {
        }

    }

    public int getEstado() {
        return nEstado;
    }

    // Devuelve al nivel que nos enctramos 
    public int getFase() {
        return nFase;
    }

    // realioza el cambio de  la portada  por el inicio del juego 
    public void accionesEstado0() {
        //verifica que se pulso la tecla espacio 
        if (htTeclas.containsKey(TEC_ESPACIO)) {
            // cambiar el valor de la variable nEstado 
            nEstado = 1;// inicia el juego 
            // iniciar la primera fase o nievel 
            nFase = 0;
            //generar metodo para iniciar  el juego en dicha fase 
            startGame();

        }
    }

    public void accionesEstado1() {
    }

    public void accionesEstado2() {
    }

    // encargado de ejecutar una  u otra opcion 
    public void acciones() {
        switch (nEstado) {
            case 0:
                accionesEstado0();
                break;
            case 1:
                accionesEstado1();
                break;
            case 2:
                accionesEstado2();
                break;

        }
    }

    // Encargado de ejecutar la aplicacion 
    public void ejecutarFrame() {
        //llamamos al metodo acciones 
        acciones();
        // System.out.println("El juego a comenzado..");
        // crear objeto de la clace bomba 
        //Bola bola = new Bola();
        // llmamamos al metodo encargado de mover ala pelota 
        if (nEstado == 1) {
            bola.Mover();
        }
    }

    // metodo encargado de generar el objeto en clace bomba 
    public void startGame() {
        //crear el objeto
        bola = new Bola();

    }

    // devolver el objeto de la clace bola 
    public Bola getBola() {
        return bola;
    }
}
