/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gamebasicmoi;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import javax.swing.JFrame;

/**
 *
 * @author moises
 */
public class GameBasicMoi extends JFrame implements Runnable {
// crear  una variable de tipo imagen 

    private Image imgPortada;
    private Image imgFase0;
    private Image imgBola;
    private Image imgJugador;

    //crear instancia de MGAme
    MGame mg = new MGame();
    //crear un buffer para agrupoar todos los metodos 
    BufferedImage bi = new  BufferedImage(1288, 725, BufferedImage.TYPE_3BYTE_BGR);
    Graphics gbi = bi.getGraphics();

    /**
     * @param args the command line arguments
     */
    /**
     * crear interfaces de vetna 800,600 mostrar al centro - finalizar proceso
     */
    public static void main(String[] args) {
        GameBasicMoi game = new GameBasicMoi();
        game.setSize(1288, 725);
        game.crearGUI();
        game.setVisible(true);
    }

    private void crearGUI() {
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setTitle("Game Moises v0.1");
        cargarImagenes();
        //Captura los eventos de teclado 
        addKeyListener(new KeyAdapter() {
            //definir los metodos  de las teclas 
            //metodo encargado  de capturar el evento cuando se presiona una tecla 
            public void keyPressed(KeyEvent evento) {
                super.keyPressed(evento);
                //obtener el codigo 
                mg.pulsaTecla(evento.getKeyCode());

            }

            // capturar el evento al soltar la tecla 
            public void keyReleased(KeyEvent evento) {
                super.keyPressed(evento);
                //obtner el codigo 
                mg.sueltaTecla(evento.getKeyCode());
            }

        });
        //crear el objeto la clace thread
        Thread hilo = new Thread(this);
        // llamar al metyodo encargado de iniciar la ejecucion del hilo
        hilo.start();
    }

    // definir metodo para cargar imagnes 
    private void cargarImagenes() {
        /**
         * Toolkit proporciona una interfaz independiente para servicios
         * especificos
         */
        Toolkit tk = Toolkit.getDefaultToolkit();
        // Cargar  la imagen indicando la ruta 
        imgPortada = tk.getImage(getClass().getResource("img/fondo.jpg"));
        imgFase0 = tk.getImage(getClass().getResource("img/fondo2.jpg"));
        imgBola = tk.getImage(getClass().getResource("img/Bola.png"));
        imgJugador = tk.getImage(getClass().getResource("img/Jugador.png"));
    }

    // definir metodo para pintar la bola 
    public void PintarBola(Graphics g) {
        
         Bola bola = mg.getBola();
        //obtener el tamaño del objeto 
        int tam = bola.getTam();
        //pintar / dibujar el objeto 
        g.drawImage(imgBola, bola.getx(), bola.getY(), tam * 2, tam * 2, this);
    }
    /**
     * Metodo encargado de dibujar el  suelo
     * @param g 
     */
   /* public void  PintarSuelo(Graphics g){
   // g.drawImage(imgSuelo, 0, 0, this);
    
    
    }*/

    //Metodo encargo de Actualizar  los graficos 
    public void update(Graphics g) {
        paint(g);

    }

    public void paint(Graphics g) {
        //verficar el estado 
        switch (mg.getEstado()) {

            case 0:
                // Muestra la imagen de introduccions
                gbi.drawImage(imgPortada, 0, 0, this);
                break;
            case 1:
                // muestra la imagen que indica qu el juegoa iniciado 
                gbi.drawImage(imgFase0, 0, 0, this);
                //pintar el suelo 
                //PintarSuelo(gbi);
                // Pintar  el objeto de bola 
                PintarBola(gbi);
                break;
            case 2:
                
                break;
        }
        //dibujar el grafico del  BufferedImage 
        g.drawImage(bi, 0, 0, this);
    }

    public void run() {
        while (true) {
            try {
                Thread.sleep(100);
            } catch (Exception e) {
            }
            //inicia la ejecucion del juego 
            mg.ejecutarFrame();
            repaint();// actualizamos los graficos 

        }
    }

}
