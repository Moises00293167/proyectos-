import java.awt.Color;
import java.awt.Graphics;
import java.util.Random;
import javax.swing.ImageIcon;
import javax.swing.JPanel;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author raide
 */
public class Bomba extends Sprite {
    private int tamMov;
    private final ImageIcon imgBomba;
    private Graphics lienzo;
    
    public Bomba(int nposX, int nposY){
        x = nposX;
        y = nposY;
        width = 10;
        height = 8;
        //Cuantos pixeles 
        tamMov = 10;
        imgBomba = new ImageIcon("bomba.png");
    }

    
     public void draw(JPanel panel){
         //Obteniendo los elementos gráficos del panel
         Graphics lienzo = panel.getGraphics();
        imgBomba.paintIcon(null, lienzo, x, y);
     }
     
     public void mover() {
            y = y + tamMov;
             
         }
}
              
          
          
           
           
  
    
    

