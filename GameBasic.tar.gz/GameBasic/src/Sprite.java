/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author raide
 */
public class Sprite {
    //Definir variables x, y, ancho, alto
    protected int x, y, width, height;
    
    // Obtenert la posición en x
    public int getX(){
        return x;
    }
    
    //Obtener la posicion en y
    public int getY(){
        return y;
    }
    //Obtener el tamaño en lo ancho
    public int getWidth(){
        return width;
    }
    //Obtener el tamaño en lo alto
    public int getHeight(){
        return height;
    }
}
