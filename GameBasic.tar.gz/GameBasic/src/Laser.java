
import java.awt.Color;
import java.awt.Graphics;
import java.util.Random;
import javax.swing.ImageIcon;
import javax.swing.JPanel;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author raide
 */
public class Laser extends Sprite {
    private final ImageIcon imgLaser;
    //Definir variable para el movimiento
    private int tamMov;
    //utilizar la biblioteca Random
    
 
    
    public Laser(int nposX, int nposY){
        x = nposX;
        y = nposY;
        width = 10;
        height = 8;
        //Cuantos pixeles
        tamMov = 10;
        imgLaser = new ImageIcon("laser.png");
    }
public void draw(JPanel panel){
         //Obteniendo los elementos gráficos del panel
         Graphics lienzo = panel.getGraphics();
         imgLaser.paintIcon(null, lienzo, x, y);
     }
     //Metodo encargado de mover al objecto (alien)
     public void mover() {
     y = y -tamMov;
             
         }
        
     }

    
    
    
    
    
     

   
              
          
          
