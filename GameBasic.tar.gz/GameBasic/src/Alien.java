
import java.awt.Color;
import java.awt.Graphics;
import java.util.Random;
import javax.swing.ImageIcon;
import javax.swing.JPanel;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author raide
 */
public class Alien extends Sprite {
    private final ImageIcon imgAlien;
    //Definir variable para el movimiento
    private int tamMov;
    //utilizar la biblioteca Random
    private Random aleatorio;
    public Alien(int tamañov){ // metodo constructor
        Random aleatoria = new Random();
        //generamos el valor aleatotio 
        x= aleatorio.nextInt(320);
        y=50;
        width=80;height=64;
        // Cuantos pixeles se va a mover el alien
        tamañov = 10;
        imgAlien = new ImageIcon("alien.jpg.png");
        
    }
    
    public Alien(){
        x = 50;
        y = 50;
        width = 80;
        height = 64;
        //Cuantos pixeles
        tamMov = 10;
        imgAlien = new ImageIcon("alien.jpg.png");
    }
     public void display(JPanel panel){
         //Obteniendo los elementos gráficos del panel
         Graphics paper = panel.getGraphics();
         // definir un color de fondo
         paper.setColor(Color.white);
         //Dibuje un rectangulo
         paper.fillRect(x-10, y, width +20, height);
         imgAlien.paintIcon(null, paper, x, y);
     }
     //Metodo encargado de mover al objecto (alien)
     public void mover() {
         //Validar si ha sobre pasado los limites del panel
         if(x > 390 || x < 1) {
             // Invertir el valor del movimiento de los pixeles 
             tamMov = -tamMov;
             
         }
         // A la posicion le sumamos el numero de pixeles que debe moverse
         x = x + tamMov;
     }
              
          }
          
           
           
  
    
    
