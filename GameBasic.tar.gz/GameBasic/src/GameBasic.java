
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import static java.lang.Math.abs;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class GameBasic extends JFrame implements ActionListener, Runnable, MouseMotionListener, MouseListener {
// definir atributos 

    private JButton btnIniciar;
    private JPanel panel;

    //creamos la instancia ala clase  Alien 
    private Alien alien;
    private Defensor defensor;
    private Laser laser;
    private Bomba bomba;

    //Definir una variable de tipo booleano para la ejecucion del hijlo 
    private boolean continuar;

    public static void main(String[] args) {
        // crear una instancia de la clace
        GameBasic game = new GameBasic();
        game.setSize(500, 600);// Definir el tamaño de JFrame
        game.setLocationRelativeTo(null);
        game.createGUI(); //Metodo de elementos graficos 
        game.setVisible(true);//Mostrar la ventana 
    }

    private void createGUI() {
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        //definimos un contenedor para los elementos 
        Container window = getContentPane();
        // Definimos  el estilo de capas paraJFrame
        window.setLayout(new FlowLayout());

        //creamos el objeto de JPanel
        panel = new JPanel();
        //Definimos el tamaño de panel 
        panel.setPreferredSize(new Dimension(480, 520));
        // definimos el color para el panel 
        panel.setBackground(Color.white);
        //Agregamos el panle ala ventana()
        window.add(panel);
        //------------------
        panel.addMouseMotionListener(this);
        panel.addMouseListener((MouseListener) this);
        //--------------------
        //creamos el boton
        btnIniciar = new JButton("iniciar ");
        //agregamos  el elemento al contenedor 
        window.add(btnIniciar);
        // Agregar el evento al boton 
        btnIniciar.addActionListener(this);

        //creamos el objeto a la clase Alien 
        alien = new Alien();
        //creamos el objeto a la clase defensor
        defensor = new Defensor();

    }

    @Override
    public void actionPerformed(ActionEvent event) {
        // SI el metodo btnIniciar se presiona
        if (event.getSource() == btnIniciar) {
            //crear el objeto de la clase Thread
            Thread t = new Thread(this);
            //ejecutar el hilo
            t.start();
            System.out.println("se presiono Boton Iniciar...");
            //llamamos al método encargado de mover el alien
            //alien.mover();
            //llamamos al método encargado de mover la bomba
            //bomba.mover();

        }

    }
    //metodo principal de ejecusion del Thread

    public void run() {
        //activar el estado de la variable continuar
        continuar = true;
        //ejecutar las acciones del hilo
        while (continuar) {
            System.out.println("java");
            //comprobar que no haya bomba activa
            if (bomba == null) //crear el objecto ala clase bomba
            {
                bomba = new Bomba(alien.getX(), alien.getY());
            }
            //Metodo encargado de mover todos los objetos
            moverTodo();
            //Método encargado de dibujar todo g
            dibujarTodo();
            //verificar el estado de los elementos
            verificarEstado();

            // indicar al hilo cada cuantos milisegundos debe ejecutarse
            retrasar();
        }
    }
    //llama a cada uno de los objetos moverse 

    public void moverTodo() {
        //llamar al metodo para mover al alien 
        alien.mover();
        if (bomba != null) {
            bomba.mover();
        }
        // verificar si puede mover el laser
        if (laser != null) {
            laser.mover();
        }
        //no va el defensor
    }
    //mostrar todos los elementos

    public void dibujarTodo() {
        Graphics lienzo = panel.getGraphics();
        lienzo.setColor(Color.white);
        //defenimos posicion y tamaño del panel 
        lienzo.fillRect(0, 0, panel.getWidth(), panel.getHeight());
        alien.display(panel);
        bomba.draw(panel);
        defensor.draw(panel);
        if (laser != null) //mostramos el elemento laser 
        {
            laser.draw(panel);
        }
        if (bomba != null) {
            bomba.draw(panel);
        }

    }
    //metodo encargado de verificar el estado de los elementos 

    public void verificarEstado() {
        //#
        if (abs(defensor.getX() - bomba.getX()) < 10000 && abs(defensor.getY() - bomba.getY()) < 10000) {

            if (bomba != null) {

                System.out.println("posion de la bomba: " + bomba.getX() + " " + bomba.getY());
                System.out.println("tamaño de la bomba : " + (bomba.getWidth() + bomba.getX()) + " " + (bomba.getHeight() + bomba.getY()));
            }
            System.out.println("posion de la defensor: " + defensor.getX() + " " + defensor.getY());
            System.out.println("tamaño de la defensor : " + (defensor.getWidth() + defensor.getX()) + " " + (defensor.getHeight() + defensor.getY()));
        }
      
        //el laser le pego al alien usuario es el ganador 
        //Definir un metodo encargado de verificar si existe una colision entre objetos
        if (colision(laser, alien)) {

            // finalizar el juego e indicar quien gano
            finalizarPartida("Usuario - Defensor" );
       
        }
        // la bomba le pego al defensor maquina la ganadora 
         if (colision(bomba, defensor)) {
            finalizarPartida("IA - Alien ");
            
        }
         if(colision(bomba,laser)){
         finalizarPartida("EMPATE ;)");
         
         }


        //validar si la bomba esta activa
        if (bomba != null) //verificar si la bomba ya salio del panel(limite inferior)
        {
            if (bomba.getY() > panel.getHeight()) // definimos bomba como null
            {
                bomba = null;
            }
        }

        //validar si el estado de laser esta activo
        if (laser != null) {
            //verificar que no haya salido del eje y
            if (laser.getY() < 0) // laser esta inativo
            {
                laser = null;
            }

        }
       
    }

    //Método para validar las colisiones  entre objetos
    // objeto1 laser - bomba
    // objeto2 alien - defensor
    private boolean colision(Sprite objeto1, Sprite objeto2) {
        //modificar la logica
        
        if (objeto1 == null || objeto2 == null) {
            return false;
        }
        System.out.println( "Overlaped X"+ areOverlaped(objeto1.getX(), objeto1.getWidth(), objeto2.getX(), objeto2.getWidth()));
        
        System.out.println("Overlaped Y"+ areOverlaped(objeto1.getY(), objeto1.getHeight(), objeto2.getY(), objeto2.getHeight()));
//validar las distancias para saber si existe una colision 
        if (areOverlaped(objeto1.getX(), objeto1.getWidth(), objeto2.getX(), objeto2.getWidth())
                && areOverlaped(objeto1.getY(), objeto1.getHeight(), objeto2.getY(), objeto2.getHeight())) {
            
            System.out.println("ya hubo colision ");
            return true;
        } else {
            return false;
        }

    }
    //método encargado de finalizar el juego - partida

    private void finalizarPartida(String ganador) {
        //cambiar el estado a la variable continuar para detener hilo 
        continuar = false;
        JOptionPane.showMessageDialog(null, "Game over - " + ganador + "gana");
        laser = null;
                bomba = null;  
        dibujarTodo();
    }

    //definimos el metodo sleep
    public void retrasar() {
        try {
            //definimos tiempo de espera para la ejecucion del hilo
            Thread.sleep(100);

        } catch (InterruptedException e) {
        }
    }
    //Eventos de moviento del mouse

    public void mouseMoved(MouseEvent evento ) {
        //obtener la posicion x del defensor
        // int posiX = defensor.getX();
        //System.out.println("pos x inicial: " + posiX);
        //llamar al método para mover al defensor 
        //defensor.mover(posiX);
        defensor.eje(evento.getX());
    }
    // metodo encargado de capturar el evento del clic
    // relacionado con el laser

    @Override
    public void mouseClicked(MouseEvent evento) {
        // Obtener las pocisiones x,y del defensor para el laser
        int posiX = defensor.getX();
        int posiY = defensor.getY();

        // CONDICIOn para verificar si el laser esta activo 
        if (laser == null) // con base en la socision del defensor 
        {
            laser = new Laser(posiX, posiY);
        }
    }

    public void mouseDragged(MouseEvent evento) {
    }

    public void mouseReleased(MouseEvent evento) {
    }

    public void mousePressed(MouseEvent evento) {
    }

    public void mouseExited(MouseEvent evento) {
    }

    public void mouseEntered(MouseEvent evento) {
    }

    private boolean areOverlaped(int obj1Pos, int obj1Tam, int obj2Pos, int obj2Tam) {
        // la posición del objeto 1 es mayor que la posición del objeto 2
        System.out.println(obj1Pos >= obj2Pos);
        if (obj1Pos >= obj2Pos) {
            // la posición del objeto 1 es menor que el tamaño del objeto 2
            // Superposición o composición
            System.out.println(obj1Pos < obj2Tam + obj2Pos);
            if (obj1Pos < obj2Tam + obj2Pos  ) {
                return true;
            }
            // la posición del objeto1 es menor que la posición del objeto 2
        } else {
            // el tamaño del objeto 1 es menor que el tamaño del objeto 2
            // Superposición
            System.out.println(obj1Tam + obj1Pos >  obj2Pos);
  
            if (obj1Tam + obj1Pos > obj2Pos ) {
                return true;
            }
        }
        return false;
    }

}
