
import java.awt.Graphics;
import javax.swing.ImageIcon;
import javax.swing.JPanel;


public class Defensor extends Sprite  {
  private final ImageIcon imgDefensor ;
   // private int tamMove;
    private int tamMov;
    public Defensor(){
        x = 300;
        y = 439;
        width =40;
        height =25;
        tamMov = 5;
        
        imgDefensor = new ImageIcon("defensor.png");
    }
     public void draw(JPanel panel){
         Graphics paper = panel.getGraphics();
         imgDefensor.paintIcon(null, paper, x, y);
     }
     public void mover(int posiX){
         //validar los limites para que no se salgan del panel
         if (x > 440 || x < 1)
             //invertir el movimiento
           tamMov = -tamMov;
         // a la pocision en x le sumamos el numero de pixeles que debe moverse
         x = x + tamMov;
             
     }

    public void eje(int ejex) {
        x = ejex;
    }

    
     
}
         